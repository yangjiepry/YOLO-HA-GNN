# training/__init__.py
# 简化版本
from .trainer import Trainer

__all__ = ['Trainer']