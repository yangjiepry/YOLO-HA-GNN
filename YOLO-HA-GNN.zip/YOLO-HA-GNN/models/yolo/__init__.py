from .yolo_with_fusion import YOLOWithFusion

__all__ = [ 'YOLOWithFusion']