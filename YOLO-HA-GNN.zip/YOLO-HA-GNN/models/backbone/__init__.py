from .dual_resnet import DualResNet

__all__ = ['DualResNet']