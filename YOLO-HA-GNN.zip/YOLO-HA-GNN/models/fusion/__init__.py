# models/fusion/__init__.py
from .adaptive_fusion import DPAFM