from .collate_fn import fusion_collate_fn
